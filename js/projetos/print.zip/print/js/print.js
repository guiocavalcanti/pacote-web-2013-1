// q1 : Dê console.log() nos valores que são avaliados para false

var q1Var1 = "hello",
    q1Var2 = 0,
    q1Var3 = true,
    q1Var4 = "false",
    q1Var5 = -1,
    q1Var6 = undefined,
    q1Var7 = null,
    q1Var8;

// BEGIN Question 1 Answer

var falseTest = function(val, str){
  if(!val) {
    console.log(str);
    console.log(val);
  }
}

// if(!q1Var1) {
//   console.log(q1Var1);
// }

falseTest(q1Var1, "q1Var1 é falso");

// if(!q1Var2) {
//   console.log("q1Var2:");
//   console.log(q1Var2);
// }

falseTest(q1Var2, "q1Var2 é falso");

if(!q1Var3) {
  console.log("q1Var3:");
  console.log(q1Var3);
}

if(!q1Var4) {
  console.log("q1Var4:");
  console.log(q1Var4);
}

if(!q1Var5) {
  console.log("q1var5:");
  console.log(q1Var5);
}

if(!q1Var6) {
  console.log("q1var6:");
  console.log(q1Var6);
}

if(!q1Var7) {
  console.log("q1var7:");
  console.log(q1Var7);
}

if(!q1Var8) {
  console.log("q1var8:");
  console.log(q1Var8);
}

// END Question 1 Answer

// q2: Concatene as strings abaixo e imprima no console:
var q3Var1 = "hello, ",
    q3Var2 = "is it me you're looking for?";

// BEGIN Question 3 Answer

var concat = q3Var1 + q3Var2;
console.log(concat);


// END Question 3 Answer


// q3: Transforme a primeira variável em um Number, some os dois valores e imprima no console.
var q4Var1 = "24",
    q4Var2 = 18;

// BEGIN Question 4 Answer

var num = parseInt(q4Var1);
var result = num + q4Var2;
console.log("Resultado da soma: " + result);


// END Question 4 Answer
